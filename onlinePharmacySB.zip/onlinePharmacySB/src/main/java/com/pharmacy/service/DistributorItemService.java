package com.pharmacy.service;


import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pharmacy.model.DistributorItemBean;
import com.pharmacy.model.ItemsBean;
import com.pharmacy.repo.DistributorItemsRepo;
import com.pharmacy.repo.ItemsRepository;

@Service
public class DistributorItemService{

	@Autowired
	private DistributorItemsRepo distributorItemRepo;

	@Autowired
	private ItemsRepository itemsRepo;

	public DistributorItemService() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DistributorItemService(DistributorItemsRepo distributorItemRepo) {
		super();
		this.distributorItemRepo = distributorItemRepo;
	}

	public DistributorItemBean addDisItem(DistributorItemBean disItem) {
		return this.distributorItemRepo.save(disItem);
	}

	@Transactional
	public void deleteItem(int id) {
		distributorItemRepo.deleteDistributorItemBeanById(id);

	}

	public List<DistributorItemBean> getAllItems() {
		return this.distributorItemRepo.findAll();
	}

	public DistributorItemBean getItemById(int id) {
		return distributorItemRepo.findById(id);
	}
	public int getQuantityItemIdAndName(int id,String itemName) {
		return distributorItemRepo.getQuantity(id,itemName);
	}
	public List<DistributorItemBean> getAllItemsByItemID(String distributor) {
		ItemsBean item = itemsRepo.findByDistributor(distributor);
		return distributorItemRepo.findByItemBean(item);
	}

	public List<DistributorItemBean> getCategoryItems(String cat) {
		List<DistributorItemBean> disres = new ArrayList<DistributorItemBean>();
		System.out.println("here " + this.itemsRepo.findByCategory(cat));
		List<ItemsBean> items = this.itemsRepo.findByCategory(cat);
		for (ItemsBean item : items) {
			disres.addAll(this.distributorItemRepo.findByItemBean(item));
			System.out.println("category " + this.distributorItemRepo.findByItemBean(item));
		}
		return disres;
	}

	public List<DistributorItemBean> getDistributorItems(List<ItemsBean> items) {
		List<DistributorItemBean> allresitems = new ArrayList<DistributorItemBean>();
		for (ItemsBean its : items) {
			List<DistributorItemBean> resitems = this.distributorItemRepo.findByItemBean(its);
			allresitems.addAll(resitems);
		}
		return allresitems;
	}

	public List<DistributorItemBean> getCartProducts(List<DistributorItemBean> items) {
		List<DistributorItemBean> products = new ArrayList<DistributorItemBean>();
		if (items.size() > 0 && items != null) {
			for (DistributorItemBean item : items) {
				float price=distributorItemRepo.getPriceById(item.getId());
				item.setPrice(item.getQuantity() * price);
				products.add(item);
			}
		}

		// TODO Auto-generated method stub
		return products;
	}
	
	

	@Transactional
	public DistributorItemBean updateDistributorItemById(DistributorItemBean disItem) {
		DistributorItemBean it = this.distributorItemRepo.save(disItem);
		return it;
	}
	
	@Transactional
	public DistributorItemBean updateItemAfterOrder(int itemsId,String itemsName,int quantity)
	{
		int itemQuantity=this.getQuantityItemIdAndName(itemsId,itemsName);
		quantity=itemQuantity-quantity;
		DistributorItemBean it = this.distributorItemRepo.findById(itemsId);
		it.setQuantity(quantity);
		return	this.distributorItemRepo.save(it);
		
	}
	

}
