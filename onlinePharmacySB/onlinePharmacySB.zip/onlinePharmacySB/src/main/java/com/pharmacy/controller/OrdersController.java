package com.pharmacy.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.pharmacy.model.DistributorItemBean;
import com.pharmacy.model.ItemsBean;
import com.pharmacy.model.OrdersBean;
import com.pharmacy.model.ParticularOrderBean;
import com.pharmacy.service.ItemsService;
import com.pharmacy.service.OrdersService;
import com.pharmacy.service.ParticularOrderProductService;

@Controller
@Transactional
public class OrdersController {

	@Autowired
	private OrdersService ordersService;
	
	@Autowired
	private ParticularOrderProductService particularOrderService;
	
	@Autowired
	private ItemsService itemService;
	
	@PostMapping("/orderplaced")
	public ModelAndView saveOrderDetails(HttpServletRequest request,Model model)
	{
		
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		HttpSession session=request.getSession();
		List<ParticularOrderBean> products = new ArrayList<>();
		List<DistributorItemBean> items=(ArrayList<DistributorItemBean>) session.getAttribute("cartList");
		float totalPrice=0.0f;
		int itemsId=0;
		int totalQuantity=0;
		ItemsBean itemBean = new ItemsBean();
		String username=(String) session.getAttribute("username");
		String date=LocalDate.now().toString();
		String distributor="";
		System.out.println("address "+address+" phone "+phone);
		for(DistributorItemBean item:items) {
			ParticularOrderBean product=new ParticularOrderBean();
			product.setItemName(item.getItemName());
			int quantity=item.getQuantity();
			float price=item.getPrice();
			product.setPrice(price);
			product.setQuantity(quantity);
			totalQuantity+=quantity;
			totalPrice+=price;
			itemsId=item.getId();
//			distributor= item.getItemBean().getDistributor();
			itemBean.setId(item.getItemBean().getId());
			
			products.add(product);
		}
		System.out.println("item id "+itemsId);
		distributor=itemService.getDistributorName(itemBean.getId());
		OrdersBean order=new OrdersBean();
		order.setDistributorName(distributor);
		order.setAddress(address);
		order.setPrice(totalPrice);
		order.setTotalQuantity(totalQuantity);
		order.setPhoneNumber(phone);
		order.setUsername(username);
		order.setOrderDate(date);
		order.setStatus("PENDING");
		String result=ordersService.addOrder(order, products);
		if(result.equals("SUCCESS")) {
			session.removeAttribute("cartList");
			session.removeAttribute("category");
			return new ModelAndView("order-success");
		}
		System.out.println(products);
		return new ModelAndView("");
		
	}
	
	
}
