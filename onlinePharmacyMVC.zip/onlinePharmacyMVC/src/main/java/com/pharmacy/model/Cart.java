package com.pharmacy.model;

public class Cart extends DistributorItemBean{
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}
