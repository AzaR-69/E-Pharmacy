package com.pharmacy.util;

public class WrongDataException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
			//write code here
		return "Data Incorrect";
	}

}
